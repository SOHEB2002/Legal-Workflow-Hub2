import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import {
  loginSchema,
  insertUserSchema,
  insertClientSchema,
  insertCaseSchema,
  insertConsultationSchema,
  insertHearingSchema,
  insertFieldTaskSchema,
  hearingResultSchema,
  hearingReportSchema,
  HearingResult,
  JudgmentSide,
  HearingStatus,
} from "@shared/schema";
import { z } from "zod";
import { randomUUID } from "crypto";
import { authMiddleware, comparePassword, generateToken } from "./auth";

// Helper function to parse pagination params
function parsePaginationParams(req: any) {
  const limit = req.query.limit ? Math.min(parseInt(req.query.limit) || 50, 100) : undefined;
  const offset = req.query.offset ? parseInt(req.query.offset) || 0 : undefined;

  return { limit, offset };
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Initialize default data on startup
  await storage.initializeDefaultData();

  // ==================== Auth Middleware ====================
  // Apply auth middleware to all routes except login
  app.use(authMiddleware);

  // ==================== Auth ====================

  app.post("/api/auth/login", async (req, res) => {
    try {
      const data = loginSchema.parse(req.body);
      const user = await storage.getUserByUsername(data.username);

      if (!user || !(await comparePassword(data.password, user.password))) {
        return res.status(401).json({ error: "اسم المستخدم أو كلمة المرور غير صحيحة" });
      }

      const token = generateToken(user.id, user.role);

      // Set token as httpOnly cookie
      res.setHeader(
        "Set-Cookie",
        `auth_token=${token}; HttpOnly; Path=/; Max-Age=86400; SameSite=Strict`
      );

      const { password, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword, token });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "حدث خطأ في الخادم" });
    }
  });

  // ==================== Users ====================

  app.get("/api/users", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users.map(u => {
        const { password, ...rest } = u;
        return rest;
      }));
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في جلب المستخدمين" });
    }
  });

  app.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ error: "المستخدم غير موجود" });
      }
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في جلب المستخدم" });
    }
  });

  app.post("/api/users", async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      const newUser = await storage.createUser(validatedData);
      const { password, ...userWithoutPassword } = newUser;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "حدث خطأ في إنشاء المستخدم" });
    }
  });

  app.patch("/api/users/:id", async (req, res) => {
    try {
      const updated = await storage.updateUser(req.params.id, req.body);
      if (!updated) {
        return res.status(404).json({ error: "المستخدم غير موجود" });
      }
      const { password, ...userWithoutPassword } = updated;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في تحديث المستخدم" });
    }
  });

  app.delete("/api/users/:id", async (req, res) => {
    try {
      await storage.deleteUser(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في حذف المستخدم" });
    }
  });

  // ==================== Cases ====================

  app.get("/api/cases", async (req, res) => {
    try {
      const { limit, offset } = parsePaginationParams(req);
      const cases = await storage.getAllCases();

      // If no pagination params provided, return all records (backward compatibility)
      if (!limit && !offset) {
        return res.json(cases);
      }

      // Apply pagination
      const start = offset || 0;
      const end = start + limit;
      const paginatedCases = cases.slice(start, end);
      const total = cases.length;
      const totalPages = Math.ceil(total / limit);

      res.json({
        data: paginatedCases,
        pagination: {
          page: Math.floor(start / limit) + 1,
          limit,
          total,
          totalPages,
        },
      });
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في جلب القضايا" });
    }
  });

  app.get("/api/cases/:id", async (req, res) => {
    try {
      const caseItem = await storage.getCaseById(req.params.id);
      if (!caseItem) {
        return res.status(404).json({ error: "القضية غير موجودة" });
      }
      res.json(caseItem);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في جلب القضية" });
    }
  });

  app.post("/api/cases", async (req, res) => {
    try {
      const validatedData = insertCaseSchema.parse(req.body);
      const createdBy = req.body.createdBy || "unknown";
      const newCase = await storage.createCase(validatedData, createdBy);
      res.status(201).json(newCase);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "حدث خطأ في إنشاء القضية" });
    }
  });

  app.patch("/api/cases/:id", async (req, res) => {
    try {
      // Validate that only allowed fields are being updated
      const allowedFields = [
        "caseType", "status", "currentStage", "stageHistory", "departmentId",
        "assignedLawyers", "primaryLawyerId", "responsibleLawyerId",
        "courtName", "courtCaseNumber", "judgeName", "circuitNumber",
        "opponentName", "opponentLawyer", "opponentPhone", "opponentNotes",
        "whatsappGroupLink", "googleDriveFolderId", "reviewNotes",
        "reviewDecision", "reviewActionTaken", "priority", "closedAt"
      ];
      
      const providedFields = Object.keys(req.body);
      const unauthorizedFields = providedFields.filter(f => !allowedFields.includes(f));
      
      if (unauthorizedFields.length > 0) {
        return res.status(400).json({
          error: "Cannot update restricted fields",
          unauthorizedFields
        });
      }

      const updated = await storage.updateCase(req.params.id, req.body);
      if (!updated) {
        return res.status(404).json({ error: "القضية غير موجودة" });
      }
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في تحديث القضية" });
    }
  });

  app.delete("/api/cases/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteCase(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "القضية غير موجودة" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في حذف القضية" });
    }
  });

  // ==================== Clients ====================

  app.get("/api/clients", async (req, res) => {
    try {
      const { limit, offset } = parsePaginationParams(req);
      const clients = await storage.getAllClients();

      // If no pagination params provided, return all records (backward compatibility)
      if (!limit && !offset) {
        return res.json(clients);
      }

      // Apply pagination
      const start = offset || 0;
      const end = start + limit;
      const paginatedClients = clients.slice(start, end);
      const total = clients.length;
      const totalPages = Math.ceil(total / limit);

      res.json({
        data: paginatedClients,
        pagination: {
          page: Math.floor(start / limit) + 1,
          limit,
          total,
          totalPages,
        },
      });
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في جلب العملاء" });
    }
  });

  app.get("/api/clients/:id", async (req, res) => {
    try {
      const client = await storage.getClientById(req.params.id);
      if (!client) {
        return res.status(404).json({ error: "العميل غير موجود" });
      }
      res.json(client);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في جلب العميل" });
    }
  });

  app.post("/api/clients", async (req, res) => {
    try {
      const validatedData = insertClientSchema.parse(req.body);
      const createdBy = req.body.createdBy || "unknown";
      const newClient = await storage.createClient(validatedData, createdBy);
      res.status(201).json(newClient);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "حدث خطأ في إنشاء العميل" });
    }
  });

  app.patch("/api/clients/:id", async (req, res) => {
    try {
      const updated = await storage.updateClient(req.params.id, req.body);
      if (!updated) {
        return res.status(404).json({ error: "العميل غير موجود" });
      }
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في تحديث العميل" });
    }
  });

  app.delete("/api/clients/:id", async (req, res) => {
    try {
      await storage.deleteClient(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في حذف العميل" });
    }
  });

  // ==================== Consultations ====================

  app.get("/api/consultations", async (req, res) => {
    try {
      const { limit, offset } = parsePaginationParams(req);
      const consultations = await storage.getAllConsultations();

      // If no pagination params provided, return all records (backward compatibility)
      if (!limit && !offset) {
        return res.json(consultations);
      }

      // Apply pagination
      const start = offset || 0;
      const end = start + limit;
      const paginatedConsultations = consultations.slice(start, end);
      const total = consultations.length;
      const totalPages = Math.ceil(total / limit);

      res.json({
        data: paginatedConsultations,
        pagination: {
          page: Math.floor(start / limit) + 1,
          limit,
          total,
          totalPages,
        },
      });
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في جلب الاستشارات" });
    }
  });

  app.get("/api/consultations/:id", async (req, res) => {
    try {
      const consultation = await storage.getConsultationById(req.params.id);
      if (!consultation) {
        return res.status(404).json({ error: "الاستشارة غير موجودة" });
      }
      res.json(consultation);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في جلب الاستشارة" });
    }
  });

  app.post("/api/consultations", async (req, res) => {
    try {
      const validatedData = insertConsultationSchema.parse(req.body);
      const createdBy = req.body.createdBy || "unknown";
      const newConsultation = await storage.createConsultation(validatedData, createdBy);
      res.status(201).json(newConsultation);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "حدث خطأ في إنشاء الاستشارة" });
    }
  });

  app.patch("/api/consultations/:id", async (req, res) => {
    try {
      const updated = await storage.updateConsultation(req.params.id, req.body);
      if (!updated) {
        return res.status(404).json({ error: "الاستشارة غير موجودة" });
      }
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في تحديث الاستشارة" });
    }
  });

  app.delete("/api/consultations/:id", async (req, res) => {
    try {
      await storage.deleteConsultation(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في حذف الاستشارة" });
    }
  });

  // ==================== Hearings ====================

  app.get("/api/hearings", async (req, res) => {
    try {
      const { limit, offset } = parsePaginationParams(req);
      const hearings = await storage.getAllHearings();

      // If no pagination params provided, return all records (backward compatibility)
      if (!limit && !offset) {
        return res.json(hearings);
      }

      // Apply pagination
      const start = offset || 0;
      const end = start + limit;
      const paginatedHearings = hearings.slice(start, end);
      const total = hearings.length;
      const totalPages = Math.ceil(total / limit);

      res.json({
        data: paginatedHearings,
        pagination: {
          page: Math.floor(start / limit) + 1,
          limit,
          total,
          totalPages,
        },
      });
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في جلب الجلسات" });
    }
  });

  app.get("/api/hearings/:id", async (req, res) => {
    try {
      const hearing = await storage.getHearingById(req.params.id);
      if (!hearing) {
        return res.status(404).json({ error: "الجلسة غير موجودة" });
      }
      res.json(hearing);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في جلب الجلسة" });
    }
  });

  app.post("/api/hearings", async (req, res) => {
    try {
      const validatedData = insertHearingSchema.parse(req.body);
      const newHearing = await storage.createHearing(validatedData);
      res.status(201).json(newHearing);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "حدث خطأ في إنشاء الجلسة" });
    }
  });

  app.patch("/api/hearings/:id", async (req, res) => {
    try {
      const updated = await storage.updateHearing(req.params.id, req.body);
      if (!updated) {
        return res.status(404).json({ error: "الجلسة غير موجودة" });
      }
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في تحديث الجلسة" });
    }
  });

  app.delete("/api/hearings/:id", async (req, res) => {
    try {
      await storage.deleteHearing(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في حذف الجلسة" });
    }
  });

  // ==================== سير عمل الجلسات المتقدم ====================

  // دالة مساعدة: البحث عن أول موظف دعم إداري نشط
  async function findAdminSupportUser(): Promise<string | null> {
    const users = await storage.getAllUsers();
    const admin = users.find(u => u.role === "admin_support" && u.isActive);
    return admin ? admin.id : null;
  }

  // دالة مساعدة: إنشاء مهمة تلقائية
  async function createAutoTask(opts: {
    title: string;
    description: string;
    taskType: string;
    caseId: string;
    assignedTo: string;
    assignedBy: string;
    priority: string;
    dueDate: string;
  }) {
    return storage.createFieldTask({
      title: opts.title,
      description: opts.description,
      taskType: opts.taskType as any,
      caseId: opts.caseId,
      assignedTo: opts.assignedTo,
      priority: opts.priority as any,
      dueDate: opts.dueDate,
    }, opts.assignedBy);
  }

  // تسجيل نتيجة الجلسة مع إنشاء المهام التلقائية
  app.post("/api/hearings/:id/result", async (req, res) => {
    try {
      const hearing = await storage.getHearingById(req.params.id);
      if (!hearing) {
        return res.status(404).json({ error: "الجلسة غير موجودة" });
      }

      const data = hearingResultSchema.parse(req.body);
      const userId = req.body.userId || "system";
      const adminUserId = await findAdminSupportUser();
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      const tomorrowStr = tomorrow.toISOString().split("T")[0];
      const nextWeek = new Date();
      nextWeek.setDate(nextWeek.getDate() + 7);
      const nextWeekStr = nextWeek.toISOString().split("T")[0];

      // تحديث بيانات الجلسة
      const updateData: any = {
        result: data.result,
        resultDetails: data.resultDetails || "",
        status: "تمت",
      };

      const createdTasks: any[] = [];

      // ======= سيناريو التأجيل: موعد جديد =======
      if (data.result === HearingResult.POSTPONEMENT) {
        updateData.nextHearingDate = data.nextHearingDate || null;
        updateData.nextHearingTime = data.nextHearingTime || null;
        updateData.responseRequired = data.responseRequired || false;
        updateData.status = "مؤجلة";

        // إنشاء جلسة جديدة تلقائياً إذا تم تحديد موعد
        if (data.nextHearingDate && data.nextHearingTime) {
          await storage.createHearing({
            caseId: hearing.caseId,
            hearingDate: data.nextHearingDate,
            hearingTime: data.nextHearingTime,
            courtName: hearing.courtName,
            courtNameOther: hearing.courtNameOther,
            courtRoom: hearing.courtRoom,
            notes: `جلسة منقولة من الجلسة السابقة بتاريخ ${hearing.hearingDate}`,
          });
        }

        // إذا لم يُحدد موعد → مهمة يومية للدعم الإداري لمتابعة الموعد
        if (!data.nextHearingDate && adminUserId) {
          const task = await createAutoTask({
            title: `متابعة تحديد موعد جديد - قضية ${hearing.caseId}`,
            description: `تم تأجيل الجلسة بتاريخ ${hearing.hearingDate} بدون تحديد موعد جديد. يرجى متابعة تحديد الموعد يومياً.`,
            taskType: "متابعة_يومية_ادارية",
            caseId: hearing.caseId,
            assignedTo: adminUserId,
            assignedBy: userId,
            priority: "عالي",
            dueDate: tomorrowStr,
          });
          createdTasks.push(task);
        }

        // إذا مطلوب رد → مهمة إعداد مذكرة
        if (data.responseRequired && adminUserId) {
          const task = await createAutoTask({
            title: `إعداد مذكرة رد - قضية ${hearing.caseId}`,
            description: `مطلوب إعداد مذكرة رد للجلسة القادمة`,
            taskType: "اعداد_مذكرة",
            caseId: hearing.caseId,
            assignedTo: adminUserId,
            assignedBy: userId,
            priority: "عاجل",
            dueDate: data.nextHearingDate || nextWeekStr,
          });
          createdTasks.push(task);

          // إذا مطلوب رد من الخصم → مهمة متابعة
          const followUpTask = await createAutoTask({
            title: `متابعة رد الخصم - قضية ${hearing.caseId}`,
            description: `متابعة ما إذا كان الخصم قد قدّم رده`,
            taskType: "متابعة_رد_الخصم",
            caseId: hearing.caseId,
            assignedTo: adminUserId,
            assignedBy: userId,
            priority: "متوسط",
            dueDate: data.nextHearingDate || nextWeekStr,
          });
          createdTasks.push(followUpTask);
        }
      }

      // ======= سيناريو الحكم =======
      if (data.result === HearingResult.JUDGMENT) {
        updateData.judgmentSide = data.judgmentSide || null;
        updateData.judgmentFinal = data.judgmentFinal ?? null;

        // حكم نهائي لصالحنا → أرشفة
        if (data.judgmentFinal && data.judgmentSide === JudgmentSide.IN_OUR_FAVOR && adminUserId) {
          const task = await createAutoTask({
            title: `أرشفة ملف القضية - ${hearing.caseId}`,
            description: `صدر حكم نهائي لصالحنا. يرجى أرشفة الملف.`,
            taskType: "ارشفة_ملف",
            caseId: hearing.caseId,
            assignedTo: adminUserId,
            assignedBy: userId,
            priority: "متوسط",
            dueDate: nextWeekStr,
          });
          createdTasks.push(task);
        }

        // حكم نهائي ضدنا → أرشفة
        if (data.judgmentFinal && data.judgmentSide === JudgmentSide.AGAINST_US && adminUserId) {
          const task = await createAutoTask({
            title: `أرشفة ملف القضية - ${hearing.caseId}`,
            description: `صدر حكم نهائي ضدنا. يرجى أرشفة الملف.`,
            taskType: "ارشفة_ملف",
            caseId: hearing.caseId,
            assignedTo: adminUserId,
            assignedBy: userId,
            priority: "متوسط",
            dueDate: nextWeekStr,
          });
          createdTasks.push(task);
        }

        // حكم غير نهائي ضدنا → تقييم جدوى الاعتراض
        if (!data.judgmentFinal && data.judgmentSide === JudgmentSide.AGAINST_US) {
          updateData.objectionFeasible = data.objectionFeasible ?? null;
          updateData.objectionDeadline = data.objectionDeadline || null;
          updateData.objectionStatus = "معلق";

          if (data.objectionFeasible && adminUserId) {
            // يوجد جدوى → إعداد لائحة اعتراض
            const task = await createAutoTask({
              title: `إعداد لائحة اعتراض - قضية ${hearing.caseId}`,
              description: `حكم غير نهائي ضدنا مع جدوى للاعتراض. يرجى إعداد لائحة الاعتراض قبل ${data.objectionDeadline || "انتهاء المهلة"}.`,
              taskType: "اعداد_لائحة_اعتراض",
              caseId: hearing.caseId,
              assignedTo: adminUserId,
              assignedBy: userId,
              priority: "عاجل",
              dueDate: data.objectionDeadline || nextWeekStr,
            });
            createdTasks.push(task);

            // مهمة تقديم اللائحة
            const submitTask = await createAutoTask({
              title: `تقديم لائحة اعتراض - قضية ${hearing.caseId}`,
              description: `يرجى تقديم لائحة الاعتراض بعد إعدادها`,
              taskType: "تقديم_لائحة",
              caseId: hearing.caseId,
              assignedTo: adminUserId,
              assignedBy: userId,
              priority: "عاجل",
              dueDate: data.objectionDeadline || nextWeekStr,
            });
            createdTasks.push(submitTask);
          }

          if (data.objectionFeasible === false && adminUserId) {
            // لا يوجد جدوى → أرشفة
            const task = await createAutoTask({
              title: `أرشفة ملف القضية - ${hearing.caseId}`,
              description: `حكم غير نهائي ضدنا بدون جدوى للاعتراض. يرجى أرشفة الملف.`,
              taskType: "ارشفة_ملف",
              caseId: hearing.caseId,
              assignedTo: adminUserId,
              assignedBy: userId,
              priority: "متوسط",
              dueDate: nextWeekStr,
            });
            createdTasks.push(task);
          }
        }

        // حكم غير نهائي لصالحنا → متابعة اعتراض الخصم
        if (!data.judgmentFinal && data.judgmentSide === JudgmentSide.IN_OUR_FAVOR && adminUserId) {
          const task = await createAutoTask({
            title: `متابعة اعتراض الخصم - قضية ${hearing.caseId}`,
            description: `صدر حكم غير نهائي لصالحنا. يرجى متابعة ما إذا اعترض الخصم.`,
            taskType: "متابعة_اعتراض_الخصم",
            caseId: hearing.caseId,
            assignedTo: adminUserId,
            assignedBy: userId,
            priority: "عالي",
            dueDate: nextWeekStr,
          });
          createdTasks.push(task);
        }
      }

      // ======= سيناريو الشطب → أرشفة =======
      if (data.result === HearingResult.DISMISSAL && adminUserId) {
        const task = await createAutoTask({
          title: `أرشفة ملف القضية - ${hearing.caseId}`,
          description: `تم شطب القضية. يرجى أرشفة الملف.`,
          taskType: "ارشفة_ملف",
          caseId: hearing.caseId,
          assignedTo: adminUserId,
          assignedBy: userId,
          priority: "متوسط",
          dueDate: nextWeekStr,
        });
        createdTasks.push(task);
      }

      // ======= سيناريو الصلح → أرشفة =======
      if (data.result === HearingResult.SETTLEMENT && adminUserId) {
        const task = await createAutoTask({
          title: `أرشفة ملف القضية (صلح) - ${hearing.caseId}`,
          description: `تم الصلح في القضية. يرجى أرشفة الملف.`,
          taskType: "ارشفة_ملف",
          caseId: hearing.caseId,
          assignedTo: adminUserId,
          assignedBy: userId,
          priority: "متوسط",
          dueDate: nextWeekStr,
        });
        createdTasks.push(task);
      }

      updateData.adminTasksCreated = createdTasks.length > 0;

      const updated = await storage.updateHearing(req.params.id, updateData);
      res.json({ hearing: updated, createdTasks });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("Error in hearing result:", error);
      res.status(500).json({ error: "حدث خطأ في تسجيل نتيجة الجلسة" });
    }
  });

  // حفظ تقرير الجلسة (إجباري قبل الإغلاق)
  app.post("/api/hearings/:id/report", async (req, res) => {
    try {
      const hearing = await storage.getHearingById(req.params.id);
      if (!hearing) {
        return res.status(404).json({ error: "الجلسة غير موجودة" });
      }

      const data = hearingReportSchema.parse(req.body);

      const updated = await storage.updateHearing(req.params.id, {
        hearingReport: data.hearingReport,
        recommendations: data.recommendations || "",
        nextSteps: data.nextSteps || "",
        contactCompleted: data.contactCompleted,
        reportCompleted: true,
      });

      res.json(updated);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "حدث خطأ في حفظ تقرير الجلسة" });
    }
  });

  // التحقق من اكتمال التقرير قبل إغلاق الجلسة
  app.post("/api/hearings/:id/close", async (req, res) => {
    try {
      const hearing = await storage.getHearingById(req.params.id);
      if (!hearing) {
        return res.status(404).json({ error: "الجلسة غير موجودة" });
      }

      // التحقق: لا يمكن إغلاق الجلسة بدون تقرير
      if (!hearing.reportCompleted) {
        return res.status(400).json({
          error: "لا يمكن إغلاق الجلسة قبل كتابة التقرير وإتمام الاتصال وكتابة المطلوب والتوصيات",
          missingFields: {
            reportCompleted: !hearing.reportCompleted,
            contactCompleted: !hearing.contactCompleted,
            hearingReport: !hearing.hearingReport,
          }
        });
      }

      if (!hearing.contactCompleted) {
        return res.status(400).json({
          error: "لا يمكن إغلاق الجلسة قبل إتمام الاتصال بالعميل",
        });
      }

      const updated = await storage.updateHearing(req.params.id, {
        status: "تمت",
      });

      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في إغلاق الجلسة" });
    }
  });

  // ==================== Field Tasks ====================

  app.get("/api/field-tasks", async (req, res) => {
    try {
      const { limit, offset } = parsePaginationParams(req);
      const tasks = await storage.getAllFieldTasks();

      // If no pagination params provided, return all records (backward compatibility)
      if (!limit && !offset) {
        return res.json(tasks);
      }

      // Apply pagination
      const start = offset || 0;
      const end = start + limit;
      const paginatedTasks = tasks.slice(start, end);
      const total = tasks.length;
      const totalPages = Math.ceil(total / limit);

      res.json({
        data: paginatedTasks,
        pagination: {
          page: Math.floor(start / limit) + 1,
          limit,
          total,
          totalPages,
        },
      });
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في جلب المهام الميدانية" });
    }
  });

  app.get("/api/field-tasks/:id", async (req, res) => {
    try {
      const task = await storage.getFieldTaskById(req.params.id);
      if (!task) {
        return res.status(404).json({ error: "المهمة غير موجودة" });
      }
      res.json(task);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في جلب المهمة" });
    }
  });

  app.post("/api/field-tasks", async (req, res) => {
    try {
      const validatedData = insertFieldTaskSchema.parse(req.body);
      const assignedBy = req.body.assignedBy || "unknown";
      const newTask = await storage.createFieldTask(validatedData, assignedBy);
      res.status(201).json(newTask);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "حدث خطأ في إنشاء المهمة" });
    }
  });

  app.patch("/api/field-tasks/:id", async (req, res) => {
    try {
      const updated = await storage.updateFieldTask(req.params.id, req.body);
      if (!updated) {
        return res.status(404).json({ error: "المهمة غير موجودة" });
      }
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في تحديث المهمة" });
    }
  });

  app.delete("/api/field-tasks/:id", async (req, res) => {
    try {
      await storage.deleteFieldTask(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في حذف المهمة" });
    }
  });

  // ==================== Contact Logs ====================

  app.get("/api/contact-logs", async (req, res) => {
    try {
      const { limit, offset } = parsePaginationParams(req);
      const logs = await storage.getAllContactLogs();

      // If no pagination params provided, return all records (backward compatibility)
      if (!limit && !offset) {
        return res.json(logs);
      }

      // Apply pagination
      const start = offset || 0;
      const end = start + limit;
      const paginatedLogs = logs.slice(start, end);
      const total = logs.length;
      const totalPages = Math.ceil(total / limit);

      res.json({
        data: paginatedLogs,
        pagination: {
          page: Math.floor(start / limit) + 1,
          limit,
          total,
          totalPages,
        },
      });
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في جلب سجلات التواصل" });
    }
  });

  app.get("/api/contact-logs/client/:clientId", async (req, res) => {
    try {
      const logs = await storage.getContactLogsByClient(req.params.clientId);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في جلب سجلات التواصل" });
    }
  });

  app.post("/api/contact-logs", async (req, res) => {
    try {
      const createdBy = req.body.createdBy || "unknown";
      const newLog = await storage.createContactLog(req.body, createdBy);
      res.status(201).json(newLog);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في إنشاء سجل التواصل" });
    }
  });

  app.patch("/api/contact-logs/:id", async (req, res) => {
    try {
      const updated = await storage.updateContactLog(req.params.id, req.body);
      if (!updated) {
        return res.status(404).json({ error: "سجل التواصل غير موجود" });
      }
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في تحديث سجل التواصل" });
    }
  });

  app.delete("/api/contact-logs/:id", async (req, res) => {
    try {
      await storage.deleteContactLog(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في حذف سجل التواصل" });
    }
  });

  // ==================== Notifications ====================

  app.get("/api/notifications", async (req, res) => {
    try {
      const { limit, offset } = parsePaginationParams(req);
      const notifications = await storage.getAllNotifications();

      // If no pagination params provided, return all records (backward compatibility)
      if (!limit && !offset) {
        return res.json(notifications);
      }

      // Apply pagination
      const start = offset || 0;
      const end = start + limit;
      const paginatedNotifications = notifications.slice(start, end);
      const total = notifications.length;
      const totalPages = Math.ceil(total / limit);

      res.json({
        data: paginatedNotifications,
        pagination: {
          page: Math.floor(start / limit) + 1,
          limit,
          total,
          totalPages,
        },
      });
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في جلب الإشعارات" });
    }
  });

  app.get("/api/notifications/user/:userId", async (req, res) => {
    try {
      const notifications = await storage.getNotificationsByRecipient(req.params.userId);
      res.json(notifications);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في جلب الإشعارات" });
    }
  });

  app.post("/api/notifications", async (req, res) => {
    try {
      const newNotification = await storage.createNotification(req.body);
      res.status(201).json(newNotification);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في إنشاء الإشعار" });
    }
  });

  app.patch("/api/notifications/:id", async (req, res) => {
    try {
      const updated = await storage.updateNotification(req.params.id, req.body);
      if (!updated) {
        return res.status(404).json({ error: "الإشعار غير موجود" });
      }
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في تحديث الإشعار" });
    }
  });

  app.delete("/api/notifications/:id", async (req, res) => {
    try {
      await storage.deleteNotification(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في حذف الإشعار" });
    }
  });

  // ==================== Departments ====================

  app.get("/api/departments", async (req, res) => {
    try {
      const departments = await storage.getAllDepartments();
      res.json(departments);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في جلب الأقسام" });
    }
  });

  app.get("/api/departments/:id", async (req, res) => {
    try {
      const department = await storage.getDepartmentById(req.params.id);
      if (!department) {
        return res.status(404).json({ error: "القسم غير موجود" });
      }
      res.json(department);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في جلب القسم" });
    }
  });

  return httpServer;
}
