import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Plus, Calendar, Clock, MapPin, AlertCircle, CheckCircle, XCircle,
  FileText, Gavel, Scale, ArrowLeft, Loader2, Eye, Lock
} from "lucide-react";
import { useHearings } from "@/lib/hearings-context";
import { useCases } from "@/lib/cases-context";
import { useClients } from "@/lib/clients-context";
import { useAuth } from "@/lib/auth-context";
import type { Hearing, HearingStatusValue, HearingResultValue, CourtTypeValue } from "@shared/schema";
import { HearingStatus, HearingResult, CourtType, JudgmentSide } from "@shared/schema";
import { format, differenceInDays, isToday } from "date-fns";
import { ar } from "date-fns/locale";

function getUrgencyColor(hearingDate: string) {
  const days = differenceInDays(new Date(hearingDate), new Date());
  if (days < 0) return "bg-muted text-muted-foreground";
  if (days === 0) return "bg-destructive text-destructive-foreground";
  if (days <= 3) return "bg-orange-500 text-white";
  if (days <= 7) return "bg-yellow-500 text-white";
  return "bg-accent text-accent-foreground";
}

function getStatusColor(status: HearingStatusValue) {
  switch (status) {
    case HearingStatus.UPCOMING:
      return "bg-primary/20 text-primary border-primary/30";
    case HearingStatus.COMPLETED:
      return "bg-accent/30 text-accent border-accent/40";
    case HearingStatus.POSTPONED:
      return "bg-orange-500/20 text-orange-600 border-orange-500/30";
    case HearingStatus.CANCELLED:
      return "bg-destructive/20 text-destructive border-destructive/30";
    default:
      return "bg-muted text-muted-foreground";
  }
}

const statusLabels: Record<HearingStatusValue, string> = {
  "قادمة": "قادمة",
  "تمت": "تمت",
  "مؤجلة": "مؤجلة",
  "ملغية": "ملغية",
};

const resultLabels: Record<HearingResultValue, string> = {
  "تأجيل": "تأجيل",
  "حكم": "حكم",
  "صلح": "صلح",
  "شطب": "شطب",
  "أخرى": "أخرى",
};

// === حالة نموذج تسجيل النتيجة ===
interface ResultFormState {
  result: HearingResultValue | "";
  resultDetails: string;
  // حقول التأجيل
  nextHearingDate: string;
  nextHearingTime: string;
  responseRequired: boolean;
  // حقول الحكم
  judgmentSide: "لصالحنا" | "ضدنا" | "";
  judgmentFinal: boolean | null;
  // حقول الاعتراض (حكم غير نهائي ضدنا)
  objectionFeasible: boolean | null;
  objectionDeadline: string;
}

const initialResultForm: ResultFormState = {
  result: "",
  resultDetails: "",
  nextHearingDate: "",
  nextHearingTime: "",
  responseRequired: false,
  judgmentSide: "",
  judgmentFinal: null,
  objectionFeasible: null,
  objectionDeadline: "",
};

// === حالة نموذج التقرير ===
interface ReportFormState {
  hearingReport: string;
  recommendations: string;
  nextSteps: string;
  contactCompleted: boolean;
}

const initialReportForm: ReportFormState = {
  hearingReport: "",
  recommendations: "",
  nextSteps: "",
  contactCompleted: false,
};

export default function HearingsPage() {
  const { hearings, isLoading, addHearing, submitResult, submitReport, closeHearing, markCancelled, getUpcomingHearings } = useHearings();
  const { cases, getCaseById } = useCases();
  const { getClientName } = useClients();
  const { user } = useAuth();

  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [resultDialog, setResultDialog] = useState<Hearing | null>(null);
  const [reportDialog, setReportDialog] = useState<Hearing | null>(null);
  const [detailsDialog, setDetailsDialog] = useState<Hearing | null>(null);
  const [resultForm, setResultForm] = useState<ResultFormState>(initialResultForm);
  const [reportForm, setReportForm] = useState<ReportFormState>(initialReportForm);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState<string | null>(null);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    caseId: "",
    hearingDate: "",
    hearingTime: "",
    courtName: "المحكمة العامة" as CourtTypeValue,
    courtRoom: "",
    notes: "",
  });

  const resetForm = () => {
    setFormData({
      caseId: "",
      hearingDate: "",
      hearingTime: "",
      courtName: "المحكمة العامة",
      courtRoom: "",
      notes: "",
    });
  };

  const handleAddHearing = async () => {
    if (!formData.caseId || !formData.hearingDate || !formData.hearingTime) return;
    try {
      setIsSubmitting(true);
      await addHearing(formData);
      setIsAddDialogOpen(false);
      resetForm();
    } catch (error) {
      setSubmitError("حدث خطأ في إضافة الجلسة");
    } finally {
      setIsSubmitting(false);
    }
  };

  // === تسجيل نتيجة الجلسة (سير العمل المتقدم) ===
  const handleSubmitResult = async () => {
    if (!resultDialog || !resultForm.result) return;
    try {
      setIsSubmitting(true);
      setSubmitError(null);
      const result = await submitResult(resultDialog.id, {
        result: resultForm.result as HearingResultValue,
        resultDetails: resultForm.resultDetails,
        judgmentSide: resultForm.result === HearingResult.JUDGMENT && resultForm.judgmentSide
          ? (resultForm.judgmentSide as "لصالحنا" | "ضدنا")
          : null,
        judgmentFinal: resultForm.result === HearingResult.JUDGMENT
          ? resultForm.judgmentFinal
          : null,
        objectionFeasible:
          resultForm.result === HearingResult.JUDGMENT &&
          !resultForm.judgmentFinal &&
          resultForm.judgmentSide === "ضدنا"
            ? resultForm.objectionFeasible
            : null,
        objectionDeadline:
          resultForm.result === HearingResult.JUDGMENT &&
          !resultForm.judgmentFinal &&
          resultForm.judgmentSide === "ضدنا" &&
          resultForm.objectionFeasible
            ? resultForm.objectionDeadline || null
            : null,
        nextHearingDate: resultForm.result === HearingResult.POSTPONEMENT
          ? resultForm.nextHearingDate || null
          : null,
        nextHearingTime: resultForm.result === HearingResult.POSTPONEMENT
          ? resultForm.nextHearingTime || null
          : null,
        responseRequired: resultForm.result === HearingResult.POSTPONEMENT
          ? resultForm.responseRequired
          : false,
        userId: user?.id,
      });

      const taskCount = result.createdTasks?.length || 0;
      setSubmitSuccess(
        taskCount > 0
          ? `تم تسجيل النتيجة وإنشاء ${taskCount} مهام تلقائية`
          : "تم تسجيل النتيجة بنجاح"
      );

      setTimeout(() => {
        setResultDialog(null);
        setResultForm(initialResultForm);
        setSubmitSuccess(null);
      }, 2000);
    } catch (error: any) {
      setSubmitError(error?.message || "حدث خطأ في تسجيل النتيجة");
    } finally {
      setIsSubmitting(false);
    }
  };

  // === حفظ تقرير الجلسة ===
  const handleSubmitReport = async () => {
    if (!reportDialog || !reportForm.hearingReport) return;
    try {
      setIsSubmitting(true);
      setSubmitError(null);
      await submitReport(reportDialog.id, reportForm);
      setSubmitSuccess("تم حفظ تقرير الجلسة بنجاح");
      setTimeout(() => {
        setReportDialog(null);
        setReportForm(initialReportForm);
        setSubmitSuccess(null);
      }, 2000);
    } catch (error: any) {
      setSubmitError(error?.message || "حدث خطأ في حفظ التقرير");
    } finally {
      setIsSubmitting(false);
    }
  };

  // === إغلاق الجلسة ===
  const handleCloseHearing = async (hearing: Hearing) => {
    try {
      setIsSubmitting(true);
      setSubmitError(null);
      await closeHearing(hearing.id);
      setSubmitSuccess("تم إغلاق الجلسة بنجاح");
      setTimeout(() => {
        setDetailsDialog(null);
        setSubmitSuccess(null);
      }, 2000);
    } catch (error: any) {
      setSubmitError(error?.message || "لا يمكن إغلاق الجلسة - تأكد من كتابة التقرير وإتمام الاتصال");
    } finally {
      setIsSubmitting(false);
    }
  };

  const openReportDialog = (hearing: Hearing) => {
    setReportForm({
      hearingReport: hearing.hearingReport || "",
      recommendations: hearing.recommendations || "",
      nextSteps: hearing.nextSteps || "",
      contactCompleted: hearing.contactCompleted || false,
    });
    setReportDialog(hearing);
  };

  const upcomingHearings = getUpcomingHearings();
  const todayHearings = hearings.filter(
    (h) => h.status === HearingStatus.UPCOMING && isToday(new Date(h.hearingDate))
  );

  const getCaseInfo = (caseId: string) => {
    const caseData = getCaseById(caseId);
    if (!caseData) return { number: "غير معروف", client: "غير معروف" };
    return {
      number: caseData.caseNumber,
      client: getClientName(caseData.clientId),
    };
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
        <span className="mr-2 text-muted-foreground">جارٍ تحميل الجلسات...</span>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* === رأس الصفحة === */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">إدارة الجلسات</h1>
          <p className="text-muted-foreground">جدول الجلسات والمواعيد وسير العمل</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-add-hearing" onClick={resetForm}>
              <Plus className="w-4 h-4 ml-2" />
              إضافة جلسة
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>إضافة جلسة جديدة</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>القضية</Label>
                <Select
                  value={formData.caseId}
                  onValueChange={(value) => setFormData({ ...formData, caseId: value })}
                >
                  <SelectTrigger data-testid="select-case">
                    <SelectValue placeholder="اختر القضية" />
                  </SelectTrigger>
                  <SelectContent>
                    {cases
                      .filter((c) => c.status !== "مغلق")
                      .map((c) => (
                        <SelectItem key={c.id} value={c.id}>
                          {c.caseNumber} - {getClientName(c.clientId)}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>التاريخ</Label>
                  <Input
                    type="date"
                    value={formData.hearingDate}
                    onChange={(e) => setFormData({ ...formData, hearingDate: e.target.value })}
                  />
                </div>
                <div>
                  <Label>الوقت</Label>
                  <Input
                    type="time"
                    value={formData.hearingTime}
                    onChange={(e) => setFormData({ ...formData, hearingTime: e.target.value })}
                  />
                </div>
              </div>
              <div>
                <Label>المحكمة</Label>
                <Select
                  value={formData.courtName}
                  onValueChange={(value: CourtTypeValue) =>
                    setFormData({ ...formData, courtName: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.values(CourtType).map((court) => (
                      <SelectItem key={court} value={court}>
                        {court}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>رقم الدائرة</Label>
                <Input
                  value={formData.courtRoom}
                  onChange={(e) => setFormData({ ...formData, courtRoom: e.target.value })}
                  placeholder="مثال: الدائرة 5"
                />
              </div>
              <div>
                <Label>ملاحظات</Label>
                <Textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="ملاحظات إضافية..."
                />
              </div>
            </div>
            <Button
              onClick={handleAddHearing}
              className="w-full"
              disabled={!formData.caseId || !formData.hearingDate || !formData.hearingTime || isSubmitting}
            >
              {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin ml-2" /> : null}
              إضافة الجلسة
            </Button>
          </DialogContent>
        </Dialog>
      </div>

      {/* === بطاقات الإحصائيات === */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">جلسات اليوم</CardTitle>
            <AlertCircle className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{todayHearings.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">الجلسات القادمة</CardTitle>
            <Calendar className="h-4 w-4 text-accent" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{upcomingHearings.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">إجمالي الجلسات</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{hearings.length}</div>
          </CardContent>
        </Card>
      </div>

      {/* === رسائل النجاح/الخطأ === */}
      {submitSuccess && (
        <div className="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-lg flex items-center gap-2">
          <CheckCircle className="w-5 h-5" />
          {submitSuccess}
        </div>
      )}
      {submitError && (
        <div className="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-lg flex items-center gap-2">
          <AlertCircle className="w-5 h-5" />
          {submitError}
          <Button variant="ghost" size="sm" onClick={() => setSubmitError(null)} className="mr-auto">
            إغلاق
          </Button>
        </div>
      )}

      {/* === جدول الجلسات === */}
      <Card>
        <CardHeader>
          <CardTitle>جدول الجلسات</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-right">التاريخ والوقت</TableHead>
                <TableHead className="text-right">القضية</TableHead>
                <TableHead className="text-right">المحكمة</TableHead>
                <TableHead className="text-right">الدائرة</TableHead>
                <TableHead className="text-right">الحالة</TableHead>
                <TableHead className="text-right">النتيجة</TableHead>
                <TableHead className="text-right">التقرير</TableHead>
                <TableHead className="text-right">الإجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {hearings.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                    لا توجد جلسات مسجلة
                  </TableCell>
                </TableRow>
              ) : (
                hearings
                  .sort((a, b) => new Date(a.hearingDate).getTime() - new Date(b.hearingDate).getTime())
                  .map((hearing) => {
                    const caseInfo = getCaseInfo(hearing.caseId);
                    return (
                      <TableRow key={hearing.id}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Badge className={getUrgencyColor(hearing.hearingDate)}>
                              {format(new Date(hearing.hearingDate), "dd MMM yyyy", { locale: ar })}
                            </Badge>
                            <span className="text-muted-foreground">{hearing.hearingTime}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div>
                            <p className="font-medium">{caseInfo.number}</p>
                            <p className="text-sm text-muted-foreground">{caseInfo.client}</p>
                          </div>
                        </TableCell>
                        <TableCell>{hearing.courtName}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <MapPin className="w-3 h-3" />
                            {hearing.courtRoom || "-"}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={getStatusColor(hearing.status)}>
                            {statusLabels[hearing.status] || hearing.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {hearing.result ? (
                            <div className="flex items-center gap-1">
                              <Badge variant="outline">
                                {resultLabels[hearing.result] || hearing.result}
                              </Badge>
                              {hearing.judgmentSide && (
                                <Badge variant={hearing.judgmentSide === "لصالحنا" ? "default" : "destructive"}>
                                  {hearing.judgmentSide}
                                </Badge>
                              )}
                            </div>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell>
                          {hearing.reportCompleted ? (
                            <Badge className="bg-green-100 text-green-800 border-green-200">
                              <CheckCircle className="w-3 h-3 ml-1" /> مكتمل
                            </Badge>
                          ) : hearing.result ? (
                            <Badge variant="outline" className="text-orange-600 border-orange-300">
                              بانتظار التقرير
                            </Badge>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            {/* زر تسجيل النتيجة: للجلسات القادمة فقط */}
                            {hearing.status === HearingStatus.UPCOMING && (
                              <>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Button
                                      size="icon"
                                      variant="ghost"
                                      onClick={() => {
                                        setResultForm(initialResultForm);
                                        setSubmitError(null);
                                        setResultDialog(hearing);
                                      }}
                                    >
                                      <Gavel className="w-4 h-4 text-primary" />
                                    </Button>
                                  </TooltipTrigger>
                                  <TooltipContent>تسجيل نتيجة الجلسة</TooltipContent>
                                </Tooltip>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Button
                                      size="icon"
                                      variant="ghost"
                                      onClick={() => markCancelled(hearing.id)}
                                    >
                                      <XCircle className="w-4 h-4 text-destructive" />
                                    </Button>
                                  </TooltipTrigger>
                                  <TooltipContent>إلغاء الجلسة</TooltipContent>
                                </Tooltip>
                              </>
                            )}

                            {/* زر التقرير: للجلسات المنتهية أو المؤجلة */}
                            {hearing.result && !hearing.reportCompleted && (
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    size="icon"
                                    variant="ghost"
                                    onClick={() => openReportDialog(hearing)}
                                  >
                                    <FileText className="w-4 h-4 text-orange-500" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>كتابة تقرير الجلسة</TooltipContent>
                              </Tooltip>
                            )}

                            {/* زر عرض التفاصيل */}
                            {hearing.result && (
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    size="icon"
                                    variant="ghost"
                                    onClick={() => {
                                      setSubmitError(null);
                                      setDetailsDialog(hearing);
                                    }}
                                  >
                                    <Eye className="w-4 h-4 text-muted-foreground" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>عرض التفاصيل</TooltipContent>
                              </Tooltip>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* ======================================= */}
      {/* === نافذة تسجيل نتيجة الجلسة المتقدمة === */}
      {/* ======================================= */}
      <Dialog open={!!resultDialog} onOpenChange={(open) => {
        if (!open) {
          setResultDialog(null);
          setResultForm(initialResultForm);
          setSubmitError(null);
        }
      }}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Gavel className="w-5 h-5" />
              تسجيل نتيجة الجلسة
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-5">
            {/* اختيار النتيجة */}
            <div>
              <Label className="text-base font-semibold">نتيجة الجلسة</Label>
              <Select
                value={resultForm.result}
                onValueChange={(value: HearingResultValue) =>
                  setResultForm({ ...initialResultForm, result: value })
                }
              >
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="اختر النتيجة" />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(resultLabels).map(([value, label]) => (
                    <SelectItem key={value} value={value}>
                      {label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* تفاصيل النتيجة */}
            <div>
              <Label>تفاصيل إضافية</Label>
              <Textarea
                value={resultForm.resultDetails}
                onChange={(e) => setResultForm({ ...resultForm, resultDetails: e.target.value })}
                placeholder="تفاصيل عن نتيجة الجلسة..."
                className="mt-1"
              />
            </div>

            {/* ====== حقول التأجيل ====== */}
            {resultForm.result === HearingResult.POSTPONEMENT && (
              <Card className="border-orange-200 bg-orange-50/50">
                <CardContent className="pt-4 space-y-4">
                  <h4 className="font-semibold text-orange-700 flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    بيانات التأجيل
                  </h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>تاريخ الجلسة الجديدة</Label>
                      <Input
                        type="date"
                        value={resultForm.nextHearingDate}
                        onChange={(e) => setResultForm({ ...resultForm, nextHearingDate: e.target.value })}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label>وقت الجلسة الجديدة</Label>
                      <Input
                        type="time"
                        value={resultForm.nextHearingTime}
                        onChange={(e) => setResultForm({ ...resultForm, nextHearingTime: e.target.value })}
                        className="mt-1"
                      />
                    </div>
                  </div>
                  {!resultForm.nextHearingDate && (
                    <p className="text-sm text-orange-600">
                      في حالة عدم تحديد موعد، ستُنشأ مهمة يومية للدعم الإداري لمتابعة تحديد الموعد
                    </p>
                  )}
                  <div className="flex items-center gap-3">
                    <Switch
                      checked={resultForm.responseRequired}
                      onCheckedChange={(checked) => setResultForm({ ...resultForm, responseRequired: checked })}
                    />
                    <Label>مطلوب رد (إعداد مذكرة)</Label>
                  </div>
                  {resultForm.responseRequired && (
                    <p className="text-sm text-orange-600">
                      ستُنشأ مهمة إعداد مذكرة ومهمة متابعة رد الخصم تلقائياً
                    </p>
                  )}
                </CardContent>
              </Card>
            )}

            {/* ====== حقول الحكم ====== */}
            {resultForm.result === HearingResult.JUDGMENT && (
              <Card className="border-blue-200 bg-blue-50/50">
                <CardContent className="pt-4 space-y-4">
                  <h4 className="font-semibold text-blue-700 flex items-center gap-2">
                    <Scale className="w-4 h-4" />
                    بيانات الحكم
                  </h4>

                  {/* طرف الحكم */}
                  <div>
                    <Label>الحكم</Label>
                    <Select
                      value={resultForm.judgmentSide}
                      onValueChange={(value) =>
                        setResultForm({
                          ...resultForm,
                          judgmentSide: value as "لصالحنا" | "ضدنا",
                          judgmentFinal: null,
                          objectionFeasible: null,
                          objectionDeadline: "",
                        })
                      }
                    >
                      <SelectTrigger className="mt-1">
                        <SelectValue placeholder="اختر طرف الحكم" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="لصالحنا">لصالحنا</SelectItem>
                        <SelectItem value="ضدنا">ضدنا</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* نهائي / غير نهائي */}
                  {resultForm.judgmentSide && (
                    <div>
                      <Label>نوع الحكم</Label>
                      <Select
                        value={resultForm.judgmentFinal === null ? "" : resultForm.judgmentFinal ? "نهائي" : "غير_نهائي"}
                        onValueChange={(value) =>
                          setResultForm({
                            ...resultForm,
                            judgmentFinal: value === "نهائي",
                            objectionFeasible: null,
                            objectionDeadline: "",
                          })
                        }
                      >
                        <SelectTrigger className="mt-1">
                          <SelectValue placeholder="اختر نوع الحكم" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="نهائي">نهائي</SelectItem>
                          <SelectItem value="غير_نهائي">غير نهائي</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  {/* رسالة للحكم النهائي */}
                  {resultForm.judgmentFinal === true && (
                    <p className="text-sm text-blue-600">
                      ستُنشأ مهمة أرشفة ملف القضية تلقائياً
                    </p>
                  )}

                  {/* حكم غير نهائي لصالحنا */}
                  {resultForm.judgmentFinal === false && resultForm.judgmentSide === "لصالحنا" && (
                    <p className="text-sm text-blue-600">
                      ستُنشأ مهمة متابعة اعتراض الخصم تلقائياً
                    </p>
                  )}

                  {/* حكم غير نهائي ضدنا → تقييم جدوى الاعتراض */}
                  {resultForm.judgmentFinal === false && resultForm.judgmentSide === "ضدنا" && (
                    <Card className="border-red-200 bg-red-50/50">
                      <CardContent className="pt-4 space-y-3">
                        <h5 className="font-medium text-red-700">تقييم جدوى الاعتراض</h5>
                        <div>
                          <Label>هل يوجد جدوى للاعتراض؟</Label>
                          <Select
                            value={resultForm.objectionFeasible === null ? "" : resultForm.objectionFeasible ? "نعم" : "لا"}
                            onValueChange={(value) =>
                              setResultForm({
                                ...resultForm,
                                objectionFeasible: value === "نعم",
                                objectionDeadline: value === "نعم" ? resultForm.objectionDeadline : "",
                              })
                            }
                          >
                            <SelectTrigger className="mt-1">
                              <SelectValue placeholder="اختر" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="نعم">نعم - يوجد جدوى</SelectItem>
                              <SelectItem value="لا">لا - لا يوجد جدوى</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        {resultForm.objectionFeasible === true && (
                          <div>
                            <Label>موعد انتهاء مهلة الاعتراض</Label>
                            <Input
                              type="date"
                              value={resultForm.objectionDeadline}
                              onChange={(e) => setResultForm({ ...resultForm, objectionDeadline: e.target.value })}
                              className="mt-1"
                            />
                            <p className="text-sm text-red-600 mt-1">
                              ستُنشأ مهام إعداد لائحة الاعتراض وتقديمها تلقائياً
                            </p>
                          </div>
                        )}

                        {resultForm.objectionFeasible === false && (
                          <p className="text-sm text-red-600">
                            ستُنشأ مهمة أرشفة ملف القضية تلقائياً
                          </p>
                        )}
                      </CardContent>
                    </Card>
                  )}
                </CardContent>
              </Card>
            )}

            {/* رسالة الشطب والصلح */}
            {(resultForm.result === HearingResult.DISMISSAL || resultForm.result === HearingResult.SETTLEMENT) && (
              <p className="text-sm text-muted-foreground bg-muted/50 p-3 rounded-lg">
                ستُنشأ مهمة أرشفة ملف القضية تلقائياً للدعم الإداري
              </p>
            )}
          </div>

          <DialogFooter className="mt-4">
            <Button
              onClick={handleSubmitResult}
              className="w-full"
              disabled={!resultForm.result || isSubmitting}
            >
              {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin ml-2" /> : null}
              تسجيل النتيجة
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ============================ */}
      {/* === نافذة كتابة التقرير === */}
      {/* ============================ */}
      <Dialog open={!!reportDialog} onOpenChange={(open) => {
        if (!open) {
          setReportDialog(null);
          setReportForm(initialReportForm);
          setSubmitError(null);
        }
      }}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              تقرير الجلسة
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-base font-semibold">
                تقرير الجلسة <span className="text-destructive">*</span>
              </Label>
              <Textarea
                value={reportForm.hearingReport}
                onChange={(e) => setReportForm({ ...reportForm, hearingReport: e.target.value })}
                placeholder="اكتب تقرير الجلسة..."
                className="mt-1 min-h-[120px]"
              />
            </div>
            <div>
              <Label>التوصيات للجلسة القادمة</Label>
              <Textarea
                value={reportForm.recommendations}
                onChange={(e) => setReportForm({ ...reportForm, recommendations: e.target.value })}
                placeholder="التوصيات..."
                className="mt-1"
              />
            </div>
            <div>
              <Label>المطلوب</Label>
              <Textarea
                value={reportForm.nextSteps}
                onChange={(e) => setReportForm({ ...reportForm, nextSteps: e.target.value })}
                placeholder="المطلوب تنفيذه..."
                className="mt-1"
              />
            </div>
            <div className="flex items-center gap-3 p-3 rounded-lg border bg-muted/30">
              <Switch
                checked={reportForm.contactCompleted}
                onCheckedChange={(checked) => setReportForm({ ...reportForm, contactCompleted: checked })}
              />
              <Label className="flex-1">
                تم إتمام الاتصال بالعميل
                <span className="text-destructive mr-1">*</span>
              </Label>
            </div>
            {!reportForm.contactCompleted && (
              <p className="text-sm text-orange-600">
                يجب إتمام الاتصال بالعميل قبل إغلاق الجلسة
              </p>
            )}
          </div>
          <DialogFooter className="mt-4">
            <Button
              onClick={handleSubmitReport}
              className="w-full"
              disabled={!reportForm.hearingReport || isSubmitting}
            >
              {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin ml-2" /> : null}
              حفظ التقرير
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ================================ */}
      {/* === نافذة تفاصيل الجلسة === */}
      {/* ================================ */}
      <Dialog open={!!detailsDialog} onOpenChange={(open) => {
        if (!open) {
          setDetailsDialog(null);
          setSubmitError(null);
        }
      }}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Eye className="w-5 h-5" />
              تفاصيل الجلسة
            </DialogTitle>
          </DialogHeader>
          {detailsDialog && (
            <Tabs defaultValue="result" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="result">النتيجة</TabsTrigger>
                <TabsTrigger value="report">التقرير</TabsTrigger>
                <TabsTrigger value="info">معلومات</TabsTrigger>
              </TabsList>

              {/* === تبويب النتيجة === */}
              <TabsContent value="result" className="space-y-4 mt-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-muted-foreground">النتيجة</Label>
                    <p className="font-medium">{detailsDialog.result ? resultLabels[detailsDialog.result] || detailsDialog.result : "-"}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">الحالة</Label>
                    <Badge className={getStatusColor(detailsDialog.status)}>
                      {statusLabels[detailsDialog.status] || detailsDialog.status}
                    </Badge>
                  </div>
                </div>

                {detailsDialog.resultDetails && (
                  <div>
                    <Label className="text-muted-foreground">تفاصيل النتيجة</Label>
                    <p className="text-sm mt-1 bg-muted/30 p-3 rounded">{detailsDialog.resultDetails}</p>
                  </div>
                )}

                {/* تفاصيل الحكم */}
                {detailsDialog.result === HearingResult.JUDGMENT && (
                  <Card className="border-blue-200">
                    <CardContent className="pt-4 space-y-3">
                      <h4 className="font-semibold text-blue-700">تفاصيل الحكم</h4>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <Label className="text-muted-foreground">الحكم</Label>
                          <p className="font-medium">{detailsDialog.judgmentSide || "-"}</p>
                        </div>
                        <div>
                          <Label className="text-muted-foreground">النوع</Label>
                          <p className="font-medium">{detailsDialog.judgmentFinal === true ? "نهائي" : detailsDialog.judgmentFinal === false ? "غير نهائي" : "-"}</p>
                        </div>
                      </div>
                      {detailsDialog.objectionStatus && (
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <Label className="text-muted-foreground">جدوى الاعتراض</Label>
                            <p className="font-medium">{detailsDialog.objectionFeasible ? "يوجد جدوى" : "لا يوجد جدوى"}</p>
                          </div>
                          <div>
                            <Label className="text-muted-foreground">مهلة الاعتراض</Label>
                            <p className="font-medium">{detailsDialog.objectionDeadline || "-"}</p>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )}

                {/* تفاصيل التأجيل */}
                {detailsDialog.result === HearingResult.POSTPONEMENT && (
                  <Card className="border-orange-200">
                    <CardContent className="pt-4 space-y-3">
                      <h4 className="font-semibold text-orange-700">تفاصيل التأجيل</h4>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <Label className="text-muted-foreground">الموعد الجديد</Label>
                          <p className="font-medium">
                            {detailsDialog.nextHearingDate || "لم يُحدد بعد"}
                            {detailsDialog.nextHearingTime && ` - ${detailsDialog.nextHearingTime}`}
                          </p>
                        </div>
                        <div>
                          <Label className="text-muted-foreground">مطلوب رد</Label>
                          <p className="font-medium">{detailsDialog.responseRequired ? "نعم" : "لا"}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}

                {detailsDialog.adminTasksCreated && (
                  <Badge className="bg-green-100 text-green-800 border-green-200">
                    <CheckCircle className="w-3 h-3 ml-1" /> تم إنشاء المهام التلقائية
                  </Badge>
                )}
              </TabsContent>

              {/* === تبويب التقرير === */}
              <TabsContent value="report" className="space-y-4 mt-4">
                {detailsDialog.reportCompleted ? (
                  <>
                    <div>
                      <Label className="text-muted-foreground">تقرير الجلسة</Label>
                      <p className="text-sm mt-1 bg-muted/30 p-3 rounded whitespace-pre-wrap">{detailsDialog.hearingReport}</p>
                    </div>
                    {detailsDialog.recommendations && (
                      <div>
                        <Label className="text-muted-foreground">التوصيات</Label>
                        <p className="text-sm mt-1 bg-muted/30 p-3 rounded whitespace-pre-wrap">{detailsDialog.recommendations}</p>
                      </div>
                    )}
                    {detailsDialog.nextSteps && (
                      <div>
                        <Label className="text-muted-foreground">المطلوب</Label>
                        <p className="text-sm mt-1 bg-muted/30 p-3 rounded whitespace-pre-wrap">{detailsDialog.nextSteps}</p>
                      </div>
                    )}
                    <div className="flex items-center gap-2">
                      <Badge className={detailsDialog.contactCompleted ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}>
                        {detailsDialog.contactCompleted ? "تم الاتصال بالعميل" : "لم يتم الاتصال بالعميل"}
                      </Badge>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-8">
                    <FileText className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
                    <p className="text-muted-foreground mb-4">لم يُكتب التقرير بعد</p>
                    {detailsDialog.result && (
                      <Button onClick={() => {
                        setDetailsDialog(null);
                        openReportDialog(detailsDialog);
                      }}>
                        كتابة التقرير
                      </Button>
                    )}
                  </div>
                )}
              </TabsContent>

              {/* === تبويب المعلومات === */}
              <TabsContent value="info" className="space-y-4 mt-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-muted-foreground">التاريخ</Label>
                    <p className="font-medium">{detailsDialog.hearingDate}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">الوقت</Label>
                    <p className="font-medium">{detailsDialog.hearingTime}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">المحكمة</Label>
                    <p className="font-medium">{detailsDialog.courtName}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">الدائرة</Label>
                    <p className="font-medium">{detailsDialog.courtRoom || "-"}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">القضية</Label>
                    <p className="font-medium">{getCaseInfo(detailsDialog.caseId).number}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">العميل</Label>
                    <p className="font-medium">{getCaseInfo(detailsDialog.caseId).client}</p>
                  </div>
                </div>
                {detailsDialog.notes && (
                  <div>
                    <Label className="text-muted-foreground">ملاحظات</Label>
                    <p className="text-sm mt-1 bg-muted/30 p-3 rounded">{detailsDialog.notes}</p>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          )}

          {/* زر إغلاق الجلسة */}
          {detailsDialog && detailsDialog.reportCompleted && detailsDialog.contactCompleted && detailsDialog.status !== HearingStatus.COMPLETED && (
            <DialogFooter className="mt-4">
              <Button
                onClick={() => handleCloseHearing(detailsDialog)}
                className="w-full"
                disabled={isSubmitting}
              >
                {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin ml-2" /> : <Lock className="w-4 h-4 ml-2" />}
                إغلاق الجلسة
              </Button>
            </DialogFooter>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
