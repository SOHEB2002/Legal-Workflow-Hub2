import { createContext, useContext, useState, useEffect, useCallback } from "react";
import type { Hearing, HearingStatusValue, HearingResultValue } from "@shared/schema";
import { HearingStatus } from "@shared/schema";
import { apiRequest } from "./queryClient";

interface HearingResultData {
  result: HearingResultValue;
  resultDetails?: string;
  judgmentSide?: "لصالحنا" | "ضدنا" | null;
  judgmentFinal?: boolean | null;
  objectionFeasible?: boolean | null;
  objectionDeadline?: string | null;
  nextHearingDate?: string | null;
  nextHearingTime?: string | null;
  responseRequired?: boolean;
  userId?: string;
}

interface HearingReportData {
  hearingReport: string;
  recommendations?: string;
  nextSteps?: string;
  contactCompleted: boolean;
}

interface HearingsContextType {
  hearings: Hearing[];
  isLoading: boolean;
  addHearing: (data: Partial<Hearing>) => Promise<Hearing>;
  updateHearing: (id: string, data: Partial<Hearing>) => Promise<void>;
  deleteHearing: (id: string) => Promise<void>;
  submitResult: (id: string, data: HearingResultData) => Promise<{ hearing: Hearing; createdTasks: any[] }>;
  submitReport: (id: string, data: HearingReportData) => Promise<Hearing>;
  closeHearing: (id: string) => Promise<Hearing>;
  markCancelled: (id: string) => Promise<void>;
  getHearingById: (id: string) => Hearing | undefined;
  getHearingsByCase: (caseId: string) => Hearing[];
  getUpcomingHearings: () => Hearing[];
  getTodayHearings: () => Hearing[];
  getHearingsInRange: (startDate: string, endDate: string) => Hearing[];
  refreshHearings: () => Promise<void>;
}

const HearingsContext = createContext<HearingsContextType | undefined>(undefined);

export function HearingsProvider({ children }: { children: React.ReactNode }) {
  const [hearings, setHearings] = useState<Hearing[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchHearings = useCallback(async () => {
    try {
      setIsLoading(true);
      const response = await fetch("/api/hearings", { credentials: "include" });
      if (response.ok) {
        const data = await response.json();
        setHearings(data);
      }
    } catch (error) {
      console.error("Error fetching hearings:", error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchHearings();
  }, [fetchHearings]);

  const addHearing = async (data: Partial<Hearing>): Promise<Hearing> => {
    const response = await apiRequest("POST", "/api/hearings", {
      caseId: data.caseId,
      hearingDate: data.hearingDate,
      hearingTime: data.hearingTime,
      courtName: data.courtName || "المحكمة العامة",
      courtNameOther: data.courtNameOther || null,
      courtRoom: data.courtRoom || "",
      status: "قادمة",
      notes: data.notes || "",
    });
    const newHearing = await response.json();
    setHearings((prev) => [newHearing, ...prev]);
    return newHearing;
  };

  const updateHearing = async (id: string, data: Partial<Hearing>): Promise<void> => {
    await apiRequest("PATCH", `/api/hearings/${id}`, data);
    setHearings((prev) =>
      prev.map((h) =>
        h.id === id
          ? { ...h, ...data, updatedAt: new Date().toISOString() }
          : h
      )
    );
  };

  const deleteHearing = async (id: string): Promise<void> => {
    await apiRequest("DELETE", `/api/hearings/${id}`);
    setHearings((prev) => prev.filter((h) => h.id !== id));
  };

  // === سير العمل المتقدم: تسجيل نتيجة الجلسة ===
  const submitResult = async (id: string, data: HearingResultData): Promise<{ hearing: Hearing; createdTasks: any[] }> => {
    const response = await apiRequest("POST", `/api/hearings/${id}/result`, data);
    const result = await response.json();
    // إعادة تحميل الجلسات لتشمل الجلسات الجديدة المنشأة تلقائياً
    await fetchHearings();
    return result;
  };

  // === حفظ تقرير الجلسة ===
  const submitReport = async (id: string, data: HearingReportData): Promise<Hearing> => {
    const response = await apiRequest("POST", `/api/hearings/${id}/report`, data);
    const updated = await response.json();
    setHearings((prev) =>
      prev.map((h) => (h.id === id ? updated : h))
    );
    return updated;
  };

  // === إغلاق الجلسة (يتطلب تقرير مكتمل) ===
  const closeHearing = async (id: string): Promise<Hearing> => {
    const response = await apiRequest("POST", `/api/hearings/${id}/close`);
    const updated = await response.json();
    setHearings((prev) =>
      prev.map((h) => (h.id === id ? updated : h))
    );
    return updated;
  };

  const markCancelled = async (id: string): Promise<void> => {
    await apiRequest("PATCH", `/api/hearings/${id}`, { status: "ملغية" });
    setHearings((prev) =>
      prev.map((h) =>
        h.id === id
          ? { ...h, status: HearingStatus.CANCELLED as HearingStatusValue, updatedAt: new Date().toISOString() }
          : h
      )
    );
  };

  const getHearingById = (id: string) => hearings.find((h) => h.id === id);

  const getHearingsByCase = (caseId: string) =>
    hearings.filter((h) => h.caseId === caseId);

  const getUpcomingHearings = () => {
    const now = new Date();
    return hearings
      .filter((h) => {
        const hearingDate = new Date(h.hearingDate);
        return h.status === HearingStatus.UPCOMING && hearingDate >= now;
      })
      .sort((a, b) => new Date(a.hearingDate).getTime() - new Date(b.hearingDate).getTime());
  };

  const getTodayHearings = () => {
    const today = new Date().toISOString().split("T")[0];
    return hearings.filter((h) => h.hearingDate === today && h.status === HearingStatus.UPCOMING);
  };

  const getHearingsInRange = (startDate: string, endDate: string) => {
    const start = new Date(startDate);
    const end = new Date(endDate);
    return hearings.filter((h) => {
      const date = new Date(h.hearingDate);
      return date >= start && date <= end;
    });
  };

  return (
    <HearingsContext.Provider
      value={{
        hearings,
        isLoading,
        addHearing,
        updateHearing,
        deleteHearing,
        submitResult,
        submitReport,
        closeHearing,
        markCancelled,
        getHearingById,
        getHearingsByCase,
        getUpcomingHearings,
        getTodayHearings,
        getHearingsInRange,
        refreshHearings: fetchHearings,
      }}
    >
      {children}
    </HearingsContext.Provider>
  );
}

export function useHearings() {
  const context = useContext(HearingsContext);
  if (context === undefined) {
    throw new Error("useHearings must be used within a HearingsProvider");
  }
  return context;
}
